import numpy as np
import pandas as pd
from scipy.signal import lfilter
import math
import csv
from control import pade, series, forced_response, bode
from AircraftIden import FreqIdenSIMO
from control import tf as transfer_func
import matplotlib.pyplot as plt
# Load data from CSV files
from AircraftIden.FreqIden import time_seq_preprocess
from sympy import symbols, Poly



with open('/home/astik/Downloads/arducopter_sysid_data/bill_sid_axis3_nohead.csv', 'r') as f:
    reader = csv.reader(f)
    data = list(reader)
arr = np.array(data)
arr = np.array(data, dtype=float)

time = arr[:, 1]
u = arr[:, 29]
    #rout_source = arr[:,2]
y = arr[:, 6]*math.pi / 180
resampled_input = time_seq_preprocess(time, u)
resampled_output = time_seq_preprocess(time, y)
# State Variable Filter: Low-pass filter
def state_variable_filter(data, alpha):
    b, a = [alpha], [1, alpha - 1]
    filtered_data = lfilter(b, a, data)
    return filtered_data

# Numerical differentiation
def numerical_diff(data, dt):
    return np.gradient(data, dt)

# Sampling interval (assuming uniform sampling)
dt = np.mean(np.diff(time))
a, b, c, d, e, f, g, tau, s = symbols("a b c d e f g tau s")
num = f * s**2
den = a * s**4 + b * s**3 + c * s**2 + d * s + e
numerator_poly = Poly(num, s)
denominator_poly = Poly(den, s)

numerator_coeffs = numerator_poly.coeffs()
denominator_coeffs = denominator_poly.coeffs()

z_terms = []
z0 = state_variable_filter(y, alpha=0.1)
z_terms.append(z0)
for i in range(1, len(denominator_coeffs)):
    z_next = numerical_diff(z_terms[-1], dt)
    z_terms.append(z_next)

# Apply SVF and calculate derivatives for input (numerator terms)
w_terms = []
w0 = state_variable_filter(u, alpha=0.1)
w_terms.append(w0)
for i in range(1, len(numerator_coeffs)):
    w_next = numerical_diff(w_terms[-1], dt)
    w_terms.append(w_next)

# Construct Z matrix (use all z_terms and -w_terms)
Z = np.column_stack(z_terms + [-w for w in w_terms])

# Construct W vector (use -z_terms[0] if W contains moved terms from output)
W = -z_terms[0]

# Estimate parameters using least squares
theta, _, _, _ = np.linalg.lstsq(Z, W, rcond=None)

# Display estimated parameters
a_estimates = theta[:len(denominator_coeffs)]
b_estimates = theta[len(denominator_coeffs):]

print("Estimated Denominator coefficients (a):", a_estimates)
print("Estimated Numerator coefficients (b):", b_estimates)
print("total init estimates", b_estimates+a_estimates)

