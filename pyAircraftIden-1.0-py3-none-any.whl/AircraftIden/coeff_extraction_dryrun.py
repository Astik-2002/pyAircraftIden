import sympy as sp

class TransferFunctionParamModel:
    def __init__(self, num, den, params, tau=0):
        self.num = num
        self.den = den
        self.tau = tau
        self.param = params
        self.s = sp.symbols('s')

    def get_unknown_param_list(self):
        def extract_coefficients(expr, s):
            poly_expr = sp.Poly(expr, s)
            coeffs = [poly_expr.coeff_monomial(s**i) for i in range(poly_expr.degree(s), -1, -1)]
            return coeffs

        num_coeffs = extract_coefficients(self.num, self.s)
        den_coeffs = extract_coefficients(self.den, self.s)

        syms = []
        for coeff in num_coeffs + den_coeffs:
            if isinstance(coeff, sp.Symbol):
                syms.append(coeff)
            else:
                syms.extend(coeff.free_symbols)

        if isinstance(self.tau, sp.Symbol):
            syms.append(self.tau)
        else:
            syms.extend(self.tau.free_symbols)

        syms = list(set(syms))
        #syms.remove(self.s)

        # Ensure the list has a specific order: [num coeffs, den coeffs, tau]
        ordered_syms = []
        for coeff in den_coeffs + num_coeffs:
            if isinstance(coeff, sp.Symbol):
                ordered_syms.append(coeff)
            else:
                ordered_syms.extend([sym for sym in coeff.free_symbols if sym in syms])
        if self.tau in syms:
            ordered_syms.append(self.tau)

        return ordered_syms

# Define symbolic parameters
a, b, c, d, e, f, g, tau, s = sp.symbols("a b c d e f g tau s")

# Define numerator and denominator with symbolic coefficients
num = f * s**2 + g*s
den = a * s**4 + b * s**3 + c * s**2 + d * s + e

# Create a TransferFunctionParamModel instance
tfpm = TransferFunctionParamModel(num, den, [a, b, c, d, e, f, tau], tau)

# Get the unknown parameters list
unknown_params_list = tfpm.get_unknown_param_list()

# Print the extracted coefficients
print("Extracted coefficients in the desired order:")
print(unknown_params_list)
