import numpy as np
import pandas as pd
from scipy.signal import lfilter, bilinear, butter, filtfilt, TransferFunction
import math
import csv
from control import pade, series, forced_response, bode_plot
from AircraftIden import FreqIdenSIMO
from control import tf as transfer_func
import matplotlib.pyplot as plt
# Load data from CSV files
from AircraftIden.FreqIden import time_seq_preprocess
from control import bode_plot, bode
import sympy as sp

def butter_lowpass(cutoff, fs, order=5):
    """
    Design a Butterworth low-pass filter.

    Parameters:
    cutoff (float): The cutoff frequency of the filter.
    fs (float): The sampling frequency of the signal.
    order (int): The order of the filter.

    Returns:
    b, a (ndarray, ndarray): Numerator (b) and denominator (a) coefficients of the filter.
    """
    nyquist = 0.5 * fs
    normal_cutoff = cutoff / nyquist
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    return b, a

def apply_lowpass_filter(data, cutoff, fs, order=5):
    """
    Apply a low-pass filter to a signal.

    Parameters:
    data (ndarray): The input signal.
    cutoff (float): The cutoff frequency of the filter.
    fs (float): The sampling frequency of the signal.
    order (int): The order of the filter.

    Returns:
    y (ndarray): The filtered signal.
    """
    b, a = butter_lowpass(cutoff, fs, order=order)
    y = filtfilt(b, a, data)
    return y

def construct_polynomial_from_coefficients(coefficients, x):
    """
    Construct a symbolic polynomial from a list of coefficients.
    
    Parameters:
    coefficients (list): List of coefficients of the polynomial, where the index represents the power of the variable.
    
    Returns:
    polynomial (sympy.Expr): The symbolic polynomial.
    """
    # Initialize the polynomial
    polynomial = 0
    
    # Get the degree of the polynomial
    degree = len(coefficients) - 1
    
    # Construct the polynomial
    for power, coefficient in enumerate(coefficients):
        polynomial += coefficient * x**(degree - power)
    
    return polynomial


def substitute_and_extract_coefficients(num, den, T):
    """
    Substitute x in the polynomial with the given expression and return the resulting coefficients.
    
    Parameters:
    coefficients (list): List of coefficients of the polynomial.
    T (float): The constant T used in the substitution.
    
    Returns:
    new_coefficients (list): List of coefficients of the resulting polynomial after substitution.
    """
    # Define the symbolic variables
    z, s = sp.symbols('z s')
    num_poly = construct_polynomial_from_coefficients(num,z)
    den_poly = construct_polynomial_from_coefficients(den,z)
    func = num_poly/den_poly
    s = 2/T*((1-1/z)/(1+1/z))
    new_func = sp.simplify(func.subs(z,s))
    print("befpre substitution",func)
    print("after substitution",new_func)
    num_new = sp.Poly(sp.numer(new_func), z)
    den_new = sp.Poly(sp.denom(new_func),z)

    # Extract the coefficients
    coefficients_num = num_new.coeffs()
    print('old num', num)
    print('new num',coefficients_num)
    coefficients_den = den_new.coeffs()
    print('old den', den)
    print('new den',coefficients_den)

    
    return coefficients_num, coefficients_den


with open('/home/astik/Downloads/arducopter_sysid_data/bill_sid_axis1_nohead.csv', 'r') as f:
       reader = csv.reader(f)
       data = list(reader)
arr = np.array(data)
arr = np.array(data, dtype=float)
    #save_data_list = ["running_time", "yoke_pitch", "theta", "airspeed", "q", "aoa", "VVI", "alt"]
    #arr = np.load("../data/sweep_data_2017_11_16_11_47.npy")
time = arr[:, 1]
u = arr[:, 23]
    #rout_source = arr[:,2]
y = arr[:, 22]*math.pi / 180
resampled_input = time_seq_preprocess(time, u)
resampled_output = time_seq_preprocess(time, y)

num_order = 3  # Order of the numerator
den_order = 5  # Order of the denominator
y = apply_lowpass_filter(y,5,100,1)
u = apply_lowpass_filter(u,5,100,1)
# Construct regression matrix Phi and output vector Y
N = len(y)
Phi = np.zeros((N - den_order, num_order + den_order))
Y = y[den_order:]

for t in range(den_order, N):
    Phi[t - den_order, :den_order] = y[t - den_order:t][::-1]  
    Phi[t - den_order, den_order:] = u[t - num_order:t][::-1]

# Handle any NaN or inf values resulting from indexing issues
Phi = np.nan_to_num(Phi)

# Least-squares estimation
theta = np.linalg.lstsq(Phi, Y, rcond=None)[0]

# Extract parameters
a_params = theta[:den_order]
b_params = theta[den_order:]

print("Estimated a parameters:", a_params)
print("Estimated b parameters:", b_params)

# Create the transfer function
num = b_params  
den = a_params 
num_new, den_new = substitute_and_extract_coefficients(b_params,a_params, 0.01)
sys_tf_discrete = transfer_func(b_params,a_params)

num_new = [float(coef) for coef in num_new]
den_new = [float(coef) for coef in den_new]

sys_tf_continous = transfer_func(list(num_new),list(den_new))
num_arr_true = [-0.053335891322632833, 0.0, 0.0]
den_arr_true =  [-2.424051991246246e-05, -0.0002765505151990164, -0.00041529913762616637, 0.0001673805896441195, -0.017578685686513985]
sys_tf_true = transfer_func(num_arr_true,den_arr_true)

# Compute Bode plot
mag, phase, omega = bode(sys_tf_discrete, plot=False)
mag_true, phase_true, omega_true = bode(sys_tf_true, plot=False)
mag_c, phase_c, omega_c = bode(sys_tf_continous, plot=False)

# Plot the magnitude and phase responses
plt.figure()
plt.subplot(2, 1, 1)
plt.semilogx(omega, 20 * np.log10(mag), label='estimated')
plt.semilogx(omega_true, 20 * np.log10(mag_true), label='true')
plt.semilogx(omega_c, 20 * np.log10(mag_c), label='continous')


plt.title('Bode Plot - Magnitude')
plt.xlabel('Frequency [rad/s]')
plt.ylabel('Magnitude [dB]')
plt.legend()
plt.grid(True)

plt.subplot(2, 1, 2)
plt.semilogx(omega, phase, label='estimated')
plt.semilogx(omega_true, phase_true, label='true')
plt.semilogx(omega_c, phase_c, label='continous')

plt.title('Bode Plot - Phase')
plt.xlabel('Frequency [rad/s]')
plt.ylabel('Phase [degrees]')
plt.legend()
plt.grid(True)

plt.show()

