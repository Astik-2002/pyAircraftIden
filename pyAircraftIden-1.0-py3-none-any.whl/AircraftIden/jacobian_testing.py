import sympy as sp

# Define symbolic variable and parameters
s, omega = sp.symbols('s omega')
a0, a1, a2, b0, b1, b2, T = sp.symbols('a0 a1 a2 b0 b1 b2 T')

# Define polynomials p(s) and q(s)
p = a0*s**2 + a1*s + a2  # Polynomial in the numerator
q = b0*s**2 + b1*s + b2  # Polynomial in the denominator

# Define the transfer function H(s)
H = (p * sp.exp(-T * s)) / q

# Define the vector of parameters
params = [a0, a1, a2, b0, b1, b2, T]

# Compute the Jacobian matrix of H w.r.t. the parameters
Jacobian_H = sp.Matrix([H]).jacobian(params)

# Display the Jacobian matrix
#print('Jacobian matrix of H with respect to the parameters:')
#sp.pprint(Jacobian_H)

H_at_iomega = H.subs(s, sp.I*omega)
Jacobian_at_iomega = Jacobian_H.subs(s, sp.I*omega)

print('Jacobian matrix of H at s = i*omega:')
sp.pprint(Jacobian_at_iomega)